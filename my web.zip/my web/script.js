document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault(); // Prevent the form from submitting normally

  // Get username and password values (they won't be used for validation)
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();

  // Redirect to index1.html regardless of the username/password entered
  window.location.href = "index1.html";
});